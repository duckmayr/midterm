#' easyRaschExample data
#' 
#' This is a list of objects of class \code{Rasch} used in the package demo
#' 
#' @name easyRaschExample
#' @docType data
NULL